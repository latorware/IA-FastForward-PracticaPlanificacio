Per executar, desde el directori on està situat aquest arxiu que estas llegint: 

	./pathDelFF/ff -o ./codi-jocsProva-Generadors/dominis/dominiQueEsVulgui.pddl -f ./codi-jocsProva-Generadors/JocsDeProves/JocQueEsVulgui.pddl


Si es vol crear un joc de proves a partir d'un generador, llavors només cal compilar el
generador que es vulgui de la carpeta /codi-jocsProva-Generadors/JocsDeProves com un arxiu java normal i corrent. 